# -*- coding: utf-8 -*-
'''
Author: Baraa Nassar
Application Name: inspired by InterMSA-Bot
Functionality Purpose: An agile Discord Bot to fit InterMSA's needs
'''

RELEASE = "v0.6.0 - 9/02/22"


import re, os, sys, time, json, datetime
from discord.utils import get

import discord

# from cmds import *
from config import *
from tools import *
from discord import ui
from discord.ext import commands
import random
from discord import app_commands
# from discord.utils import get


RUN_TIME = datetime.datetime.now()
LAST_MODIFIED = RUN_TIME.strftime("%m/%d/%Y %I:%M %p")
# RELEASE += f" ({ENV})"

class Unbuffered(object):
    def __init__(self, stream):
        self.stream = stream
    def write(self, data):
        self.stream.write(data)
        self.stream.flush()
    def writelines(self, datas):
        self.stream.writelines(datas)
        self.stream.flush()
    def __getattr__(self, attr):
        return getattr(self .stream, attr)
sys.stdout = Unbuffered(sys.stdout)


class Confirm(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        # super().__init__()
        self.value = None

    # When the confirm button is pressed, set the inner value to `True` and
    # stop the View from listening to more input.
    # We also send the user an ephemeral message that we're confirming their choice.
    @discord.ui.button(label='Verify', style=discord.ButtonStyle.green, custom_id='persistent_view:green')    
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(Questionnaire())
        self.value = True


class Bot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True

        super().__init__(command_prefix=commands.when_mentioned_or('>'), intents=intents)

    async def on_ready(self):
        print(f'Logged in as {self.user} (ID: {self.user.id})')

        print('------')
  
    async def setup_hook(self) -> None:
        self.add_view(Confirm())
        

bot = Bot()
@bot.event
async def on_message(message,*args):
    if message.author == bot.user:
        return -1;
    # Exclusive Experimental Commands
    userMessage = message.content.lower() 

    if (userMessage.startswith("flip a coin")) or (userMessage.startswith("flip coin")):
        faceCoin = ["heads","tails"]
        await message.reply(random.choice(faceCoin))

    dice=["dice",'die','di','dic']
    if userMessage.startswith(f"roll a di"):
        await message.reply("🎲"+str(random.randint(1,6)))

    if message.content.startswith('>fetch'): # Add user officially  in case the >add doesn't work, this is a backup
       #you cannot write the names with this command
       # /add or >add @username

       is_admin = check_admin(message, add_on="Admin")
       if not is_admin:
          return -1
       #if len(args) <= 1: # If user already has full name

       if is_admin:
          user_id = re.search(r"\d{5,}", message.content)
          #user_id = re.search(r"\d{5,}", args[0])
          #print (args[0])
          if user_id:
             guild = bot.get_guild(SERVER_ID)
             member = guild.get_member(int(user_id.group()))

             sibling = get_sibling_role(member)
             rm_role = get_sibling_role(member)
             print ("guild is", guild)
             #print("type guild is",type(guild))
             print ("groupID", (int (user_id.group())))

             role = get(bot.get_guild(SERVER_ID).roles, name=f"{sibling}")
             rm_role =  get(bot.get_guild(SERVER_ID).roles, name=f"{sibling}s Waiting Room")
             not_verify_role = discord.utils.get(guild.roles, name = 'not-verified')

             await member.add_roles(role)
             # await member.remove_roles(rm_role,not_verify_role)
             await member.remove_roles(rm_role)

             siblinghood = get_sibling(sibling)
             channel = bot.get_channel(siblinghood.general)
             #channel = bot.get_channel(9248729487408)

               #"
             if str(sibling) == "Brother":
                await channel.send("<@!" + user_id.group() + "> " + "Salam and Welcome\nPlease check out <#934526938742145054> to get roles")

             if str(sibling) == "Sister":
                await channel.send("<@!" + user_id.group() + "> " + "Salam and Welcome\nPlease check out <#937494516829679636> to get roles")
                #await channel.send("<@!" + user_id.group() + "> " + random.choice(greeting))

          else:
             await message.channel.send("**Invalid command! Please make sure you're @ing the user.**", delete_after=25)
             await message.delete(delay=300)

          #else:
          #   await ctx.send("**Invalid command! Please make sure you're @ing the user.**", delete_after=25)
             #await ctx.delete(delay=300)


    # Exclusive Experimental Commands

    # Shared Announcment System

    if listen_announce(message): # Send to alternate announcement channel
        announce_channel = listen_announce(message)
        channel = bot.get_channel(announce_channel)
        await channel.send(
    message.content, files=[await f.to_file() for f in message.attachments])


    await bot.process_commands(message)

    # The Verification System

# bot = Bot()
@bot.command()
async def ping(ctx):
    await ctx.send('pong')

@bot.command()
async def ask(ctx: commands.Context):
    """Asks the user a question to confirm something."""
    # We create the view and assign it to a variable so we can wait for it later.
    view = Confirm()
    await ctx.send('Click below to continue', view=view)
    # Wait for the View to stop listening for input...
    await view.wait()
    if view.value is None:
        print('Timed out...')
    elif view.value:
        print('Confirmed...')
    else:
        print('Cancelled...')


    #Use the email to send a msg to the person who verified stating that someone has joined the server with their mail
    #If it wasn't them then they should let us know about it. 
    #also put the name that they put
    
class Questionnaire(ui.Modal, title='Questionnaire Response'):
    name = ui.TextInput(label='Name')
    email = ui.TextInput(label='Email', placeholder= "person@montclair.edu", style=discord.TextStyle.short)
    gender = ui.TextInput(label='gender', placeholder="brother or sister?", style=discord.TextStyle.short)

    async def on_submit(self, interaction: discord.Interaction):
            # self.name
            # self.email
            # self.gender
        # await interaction.response.send_message(f'Thanks for your response, {self.name}!', ephemeral=True)
        await interaction.user.edit(nick=str(self.name))
        email_addr = str(self.email)
        gender =str(self.gender).capitalize() #!!!

        if get_sibling(gender) == None :

        # if not re.search(r"(bro(ther)?s?|sis(tas?|ters?)|work(force)?)", gender):
            return await interaction.response.send_message('Please enter Correct Gender `brother` or `sister`', ephemeral=True)
       
        elif not re.search(r"^.+@.+\.", email_addr):
            return await interaction.response.send_message('Please enter Correct email address', ephemeral=True)
        # else:
            # await interaction.response.send_message(f'Thanks for your response,\nname: {self.name} \ncollege: {self.college}\nemail: {self.email}\npro? {self.isStudent}\ngender: {self.gender}!', ephemeral=True)

        # print (email_addr)



        guild = bot.get_guild(SERVER_ID); pro = False; c_role = "N/A"

        # print (f"")
        # print (f"")
    
        if not pro or ".edu" not in email_addr:
            print(gender)

            role = get(guild.roles, name=f"{gender}s Waiting Room")
            await interaction.user.add_roles(role) # Add Waiting Room role to user


        gender = str(self.gender).capitalize()
        sibling = get_sibling(gender) # Get brother/sister/pro object
        

        channel = bot.get_channel(sibling.wait) # Waiting room channel
                # channel
    
        if str(channel) == "sis-wait":
            await channel.send(f"Salam "+interaction.user.mention+f"! please wait until ||<@&1019382986271096941> <@&1019382986271096940>|| to adds you ")
            await channel.send(f'> name: {self.name} *\n> email: **{self.email}**\n> gender: **{self.gender}**!')
            #await channel.send(f"*** You came from {c_role.mention} " + message.author.mention + "***" + " *please wait until <@&792258252062064670> adds you*")
         
        elif str(channel) == "bro-wait":
            
            #await channel.send(f"*** You came from {c_role.mention} " + message.author.mention + "***" + " *please wait until <@&780660920363515914> adds you*")
            # channel
            await channel.send(f"Salam "+interaction.user.mention+f"! please wait until ||<@&1019382986271096941> <@&1019382986271096940>|| to adds you ")
            await channel.send(f'> name: {self.name} *\n> email: **{self.email}**\n> gender: **{self.gender}**!')



        else:
            await channel.send("yo")

    # else: # pro wait channel
        # channel = bot.get_channel(sibling.wait) # Waiting room channel
        # msg = await channel.send(f"@here " + message.author.mention + " *has joined the InterMSA Discord!*")
        # await channel.send(f'> name: {self.name} from **\n> email: **{self.email}**\n>  gender: **{self.gender}**!')

# Bot Starting Point
bot.run('TOKEN')
# if __name__ == "__main__":
#     token = BOT
#     bot.run(token)

##bot.logout()
##bot.close()
##print("We have logged out of bot bot")
