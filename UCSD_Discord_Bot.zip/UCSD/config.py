#this file has all the ID for the server 
import re
# from key import *
# from discord.ext import commands


# Object for representing a partition in a server
class ServerPartition(object):
   #__slots__ = ("name", "wait", "general", "announce")
   def __init__(self, name, wait, general, announce, **kwargs):
      self.__dict__.update(kwargs)
      self.name = name
      self.wait = wait
      self.general = general
      self.announce = announce


# Attributes to add on to ServerPartition object(s)
__bro_add_ons = {"role_select": 792531850740498482,
                 "events": 811467259225702480}
__sis_add_ons = {"role_select": 792531967832227841,
                 "events": 811471035332296740}
__pro_add_ons = {"role_select": 793371378736431144}

# Set all global variables
# PROS, BROTHERS & SISTERS represent the server partitions
BROTHERS = ServerPartition("Brother", 1019382987982393398,
                  1019382987982393403, 1019382987525193732,
                  **__bro_add_ons)
SISTERS = ServerPartition("Sister", 1019382987525193736,
                 1019382989643333749, 1019382987525193735,
                 **__sis_add_ons)


           #"join
# Retrieve passwords/secrets
# BOT = os.getenv("BOT_SECRET", bot_pass())
# VERIFY_SITE = "https://VerificationSystem.intermsa.repl.co"
# SP = os.getenv("SECRET_PASS", secret_pass())
# DB_SECRET = re.sub(r"\\n", '\n', os.getenv("DB_SECRET", db_pass()))
#ENCRYPT_KEY = re.sub(r"\\n", '\n', os.getenv("PUBLIC_KEY", pub_pass()))
# APP_PASS = os.getenv("EMAIL_SECRET", email_pass())
# DB_PATH = "database/database.db"

# Needed ID's
VERIFY_ID = 1019382987982393401 # #verify chat channel
SERVER_ID = 1019382986157858956 # Server ID

#-----

# Last globals and config setup
DEVS = [233691753922691072, 714641624571052076, 670325339263860758,
        508654889002467329, 714618776020320396, 459493208905220138,
        732373611775524926, 562285596668723219, 761123575021174784,693284211083182111]
#COMMAND_PREFIX = '/'
COMMAND_PREFIX =["/",">"]



'''
Notes:
- Create Server
- Create Brother/Sister, Owner, Waiting oom roles role
- Create #verify chat
- Create waiting rooms
- Create Bro/Sis Categories
- Set Perms
- Enable Developer Mode
  Copy ID's:
  - Right click on Server Name
  - Right click on #verify chat
  - Right click on #general chats for brothers & sisters
- Make @everyone role only able to talk in #verify chat
- Remove all permissions from @everyone role except for send messages
'''
