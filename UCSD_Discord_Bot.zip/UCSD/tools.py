from config import *
from discord.utils import get
def check_gender(user):
    roles = user.roles
    for role in roles:
        if role.name == "Brother" or role.name == "Sister":
            return role.name

# Return true if user is admin or another role
def check_admin(msg, add_on=''):
    roles = msg.author.roles
    for role in roles:
        if role.name == "Admin" or "Shura" in role.name:
            return True
        if role.name == add_on:
            return True
    return False

def listen_announce(msg):
    if msg.channel.id == BROTHERS.announce:
        if ("test2" in msg.content) or(("@everyone" in msg.content)):
            return SISTERS.announce
    elif msg.channel.id == SISTERS.announce:
        if (("@everyone" in msg.content)):
            return BROTHERS.announce
    elif msg.channel.id == BROTHERS.events:
        if (("@everyone" in msg.content)):
            return SISTERS.events
    elif msg.channel.id == SISTERS.events:
        if (("@everyone" in msg.content)):
            return BROTHERS.events
    else:
        False

def get_sibling_role(member):
    roles = member.roles; ret = None
    # for role in roles:

    # if (role.name == "Brothers Waiting Room") in member.roles:
    if get(roles, name = "Brothers Waiting Room"):#if the id is Brothers Waiting Room
        # print ("hi")
        ret = ("Brother"); 

    if get(roles, name = "Sisters Waiting Room"):#if the id is Brothers Waiting Room
        ret = ("Sister"); 

    if get(roles, name = "Pros Waiting Room"):#if the id is Brothers Waiting Room
        ret = ("Professional", role); 
    return ret

def get_sibling(sibling):
    if sibling.lower() == "brother" or sibling.lower() == "male" or sibling.lower()==sibling.startswith("bro"):
        return BROTHERS
    elif sibling.lower() == "sister" or sibling.lower() == "female" or  sibling.lower() ==sibling.startswith("sis"):
        return SISTERS
    else:
        return None
